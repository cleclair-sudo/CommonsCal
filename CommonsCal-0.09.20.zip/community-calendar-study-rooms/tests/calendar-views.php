<?php
// Run with: php tests/calendar-views.php
define('ABSPATH', __DIR__ . '/');
function add_shortcode() {}
function wp_timezone() { return new DateTimeZone('America/New_York'); }
function calsys_week_start_day() { return $GLOBALS['week_start']; }
function sanitize_key($value) { return preg_replace('/[^a-z0-9_\-]/', '', strtolower($value)); }
function wp_unslash($value) { return $value; }
function current_time($format) { return $format === 'Y-m' ? '2026-11' : '2026-11-11'; }
function esc_attr($value) { return htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); }
function expect($condition, $message) {
    if (!$condition) { fwrite(STDERR, $message . "\n"); exit(1); }
}
require __DIR__ . '/../includes/calendars.php';

$month = new DateTimeImmutable('2026-11-01', wp_timezone());
$date = new DateTimeImmutable('2026-11-30', wp_timezone());
$week_start = 1;
list($start, $end) = calsys_calendar_range($month, 'week', $date);
expect($start->format('Y-m-d') === '2026-11-30' && $end->format('Y-m-d') === '2026-12-07', 'Week must span month boundaries');
list($start, $end) = calsys_calendar_range($month, 'day', $date);
expect($start->format('Y-m-d') === '2026-11-30' && $end->format('Y-m-d') === '2026-12-01', 'Day range must be one calendar day');
list($start, $end) = calsys_calendar_range($month, 'month', $date);
expect($start->format('Y-m-d') === '2026-10-26' && $end->format('Y-m-d') === '2026-12-07', 'Month must preserve the six-week grid');
$week_start = 0;
list($start, $end) = calsys_calendar_range($month, 'week', new DateTimeImmutable('2026-11-04', wp_timezone()));
expect($start->format('Y-m-d') === '2026-11-01' && $end->format('Y-m-d') === '2026-11-08', 'Week must honor configured week start across DST');

$_GET = array('calsys_view' => 'week', 'calsys_date' => '2026-02-29');
list($view, $selected) = calsys_calendar_view_state($month);
expect($view === 'week' && $selected->format('Y-m-d') === '2026-11-11', 'Invalid date must fall back to today');
$_GET = array('calsys_view' => array('day'), 'calsys_date' => '2026-12-01');
list($view, $selected) = calsys_calendar_view_state($month);
expect($view === 'month' && $selected->format('Y-m-d') === '2026-12-01', 'Invalid view must fall back to month');
$fields = calsys_calendar_hidden_query_fields(array('page_id' => '6', 'filter' => array('x' => '<value>')));
expect(strpos($fields, 'name="page_id" value="6"') !== false && strpos($fields, 'name="filter[x]" value="&lt;value&gt;"') !== false, 'Query parameters must be retained and escaped');
echo "Calendar views passed.\n";
